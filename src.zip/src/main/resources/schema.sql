CREATE DATABASE IF NOT EXISTS zidioconnect;
USE zidioconnect;