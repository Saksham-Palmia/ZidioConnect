package com.jobPortal.dto;

public class ApplicationTrackDTO {
    private String date;
    private long applications;
    
    // Getters and Setters
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    
    public long getApplications() { return applications; }
    public void setApplications(long applications) { this.applications = applications; }
}