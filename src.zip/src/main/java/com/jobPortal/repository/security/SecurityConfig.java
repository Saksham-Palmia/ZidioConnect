package com.jobPortal.repository.security;

public class SecurityConfig {
    
}
