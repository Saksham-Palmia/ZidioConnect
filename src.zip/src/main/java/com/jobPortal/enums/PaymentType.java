package com.jobPortal.enums;

public enum PaymentType {
    CREDIT_CARD, DEBIT_CARD, UPI
}