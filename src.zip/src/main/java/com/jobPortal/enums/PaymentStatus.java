package com.jobPortal.enums;

public enum PaymentStatus {
    PAYMENT_SUCCESSFUL, PAYMENT_FAILED
}