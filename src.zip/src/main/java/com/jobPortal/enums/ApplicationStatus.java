package com.jobPortal.enums;

public enum ApplicationStatus {
    PENDING,
    REVIEWED,
    SHORTLISTED,
    REJECTED,
    ACCEPTED
}