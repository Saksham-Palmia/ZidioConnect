package com.jobPortal.enums;

public enum UserRole {
    STUDENT,
    RECRUITER,
    ADMIN
}