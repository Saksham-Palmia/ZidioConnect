package com.jobPortal.enums;

public enum PaidStatus {
    ACTIVE, EXPIRED, CANCELLED
}